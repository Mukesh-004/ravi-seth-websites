# Ravi Seth Estate package

This package is one independent deployment. Its home page is /estate.html and /.
Copy .env.example to .env, set ADMIN_TOKEN, then run npm run dev:env.
For Docker deployment, use the included README.md and Compose file.
The backend and Content Studio are included. The estate and boutique packages use separate SQLite databases when deployed separately.
Sample listings and remote illustrative photos must be replaced before public launch.
